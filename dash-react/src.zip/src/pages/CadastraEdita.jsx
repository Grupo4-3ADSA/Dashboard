import React, { useState } from "react";
import '../html-css-template/css/style.css';
import '../html-css-template/css/style-componentes.css';
import DashGenerica from '../pages/DashGenerico';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import NavSupEsquerdo from '../componentes/navbar/NavSupEsquerdo';
import NavSupCentro from '../componentes/navbar/NavSupCentro';
import NavEsquerdo from '../componentes/navbar/NavEsquerdo';

function EditarCadastrar() {
    const navigate = useNavigate();

    return (
        <>
            <div clas="container">
                {/* vem nav */}
                <div class="superior">
                    <NavSupEsquerdo />
                    <NavSupCentro />
                </div>
                <div class="nav-esquerda">
                    <NavEsquerdo />
                </div>
                <div class="conteudo">
                    <div className="box-btn-cadastro">
                        <h2 className="h2-titulo">Cadastrar ou editar</h2>
                        <button onClick={() => (<DashGenerica abra={"/salas"} />)}>Salas</button>
                        <button>Ar-Condicionado</button>
                        <button>Lampadas</button>
                        <button>Tomadas</button>
                        <button>Dispositivo-Cln</button>
                    </div>
                </div>
            </div>
        </>
    )

}

export default EditarCadastrar;