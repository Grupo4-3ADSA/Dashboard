import React, { useState, useEffect } from "react";
import api from '../Api'
import '../html-css-template/css/style.css';
import '../html-css-template/css/style-componentes.css';
import ImgPainelControle from '../html-css-template/imagens/painel-controle.png';
import ImgCentralAjuda from '../html-css-template/imagens/central-ajuda.png';
import ImgRelatorio from '../html-css-template/imagens/relatorio.png';
import ImgCadastrarEditar from '../html-css-template/imagens/edicad.png';
import ListaHome from "../componentes/listas/ListaHome";
import NavSupEsquerdo from '../componentes/navbar/NavSupEsquerdo';
import NavSupCentro from '../componentes/navbar/NavSupCentro';
import NavEsquerdo from '../componentes/navbar/NavEsquerdo';

function Home(props) {

    const [rooms, setRooms] = useState([]);
    console.log(rooms)

    useEffect(() => {
        api.Api.get("/rooms")
            .then(response => {
                setRooms(response.data)
            })
            .catch(erro => {
                console.log(erro)
            })
    }, [])

    return (
        <>
            <div clas="container">
                {/* vem nav */}
                <div class="superior">
                    <NavSupEsquerdo />
                    <NavSupCentro />
                </div>
                <div class="nav-esquerda">
                    <NavEsquerdo />
                </div>
                <div class="conteudo">
                    <h2 className="h2-titulo">Com o nosso sistema você não emitiu 0,4 de co2 economizando R$ 20,00</h2>
                    <div className="btns-direcionar">
                        <div className="direcionar">
                            <img src={ImgPainelControle} alt="" />
                            <h4>Painel de controle</h4>
                        </div>
                        <div className="direcionar">
                            <img src={ImgRelatorio} alt="" />
                            <h4>Relatório de fatura</h4>
                        </div>
                        <div className="direcionar">
                            <img src={ImgCadastrarEditar} alt="" />
                            <h4>Cadastros</h4>
                        </div>
                        <div className="direcionar">
                            <img src={ImgCentralAjuda} alt="" />
                            <h4>Central de ajuda</h4>
                        </div>

                    </div>

                    <div className="box-salas">
                        <div className="box-list">
                            <h2 className="title-list">Salas que estão mais consumindo neste momento:</h2>
                            <div className="list">
                                <ul>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    {
                                        rooms.map(rooms => (
                                            <ListaHome
                                                name={rooms.name}
                                                floor={rooms.floor}

                                            />
                                        ))
                                    }
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>

    )
}

export default Home;