import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";

import RotaSalas from "../src/componentes/listas/ListaSalas";
import RotaPainelControle from "./componentes/PainelControle";
import RotaConsumoEquipamento from "./componentes/ConsumoEquipamento";
import RotaResumoConsumo from "./componentes/ResumoConsumo";
import RotaCentralAjuda from "./componentes/CentralAjuda";
import RotaCadastro from "./pages/HomeDash";
import Nav from "./componentes/navbar/NavSupCentro";
import Rota from "./componentes/CentralAjuda";


function Rotas() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" exact element={<Login />} />
                    <Route path="/salas" exact element={<RotaSalas />} />
                <Route path="/painel-controle" exact element={<RotaPainelControle />} />
                <Route path="/consumo-equipamento" exact element={<RotaConsumoEquipamento />} />
                <Route path="/resumo-consumo" exact element={<RotaResumoConsumo />} />
                <Route path="/central-ajuda" exact element={<RotaCentralAjuda />} />

                <Route path="/cadastro" exact element={<RotaCadastro />} />
                <Route path="/nav" exact element={<Nav />} />

            </Routes>
        </BrowserRouter>
    )
}

export default Rotas;