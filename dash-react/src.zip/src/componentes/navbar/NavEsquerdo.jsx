
import React, { useState } from "react";
import '../../html-css-template/css/style.css';

function ItemNavEsq(props) {
    return (
        <>
            <ul class="list-nav-esqueda">
                <li>Home</li>
                <li>Cadastrar/Editar</li>
                <li>Salas</li>
                <li>Painel de controle</li>
                <li>Consumo/equipamento</li>
                <li>Resumo de consumo</li>
                <li>Central de ajuda</li>
            </ul>
        </>

    )

}

export default ItemNavEsq;