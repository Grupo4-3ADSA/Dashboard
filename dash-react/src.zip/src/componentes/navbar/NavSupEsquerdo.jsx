
import React, { useState } from "react";
import '../../html-css-template/css/style.css';
import LogoOnclnBranco from '../../html-css-template/imagens/logo-branco.png';

function ItemNavSupEsq(props) {
    return (    
        <>
                <div class="nav-superior-esquerda">
                    <img src={LogoOnclnBranco} alt="Logo" />
                </div>
        </>

    )

}

export default ItemNavSupEsq;